/*
# Create surprise_reactions table

1. Purpose
- Stores the visitor's reaction to the final birthday surprise ("did you like it?").
- Single-tenant, no-auth app: anyone reaching the final step can submit a reaction.

2. New Tables
- `surprise_reactions`
  - `id` (uuid, primary key)
  - `reaction` (text, not null) — e.g. "loved-it", "liked-it", "okay"
  - `note` (text, nullable) — optional short message back to Filza
  - `created_at` (timestamptz, default now())

3. Security
- Enable RLS on `surprise_reactions`.
- Allow anon + authenticated CRUD because the data is intentionally public/shared
  (a no-auth birthday surprise site).
*/

CREATE TABLE IF NOT EXISTS surprise_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reaction text NOT NULL,
  note text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE surprise_reactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_reactions" ON surprise_reactions;
CREATE POLICY "anon_select_reactions" ON surprise_reactions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reactions" ON surprise_reactions;
CREATE POLICY "anon_insert_reactions" ON surprise_reactions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_surprise_reactions_created_at
  ON surprise_reactions (created_at DESC);
