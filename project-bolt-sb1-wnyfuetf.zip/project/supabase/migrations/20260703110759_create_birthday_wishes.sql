/*
# Create birthday_wishes table

1. Purpose
- Stores birthday wishes/messages left by visitors for the birthday friend.
- This is a single-tenant, no-auth app: anyone visiting the site can read all
  wishes and add a new one. There is no sign-in screen.

2. New Tables
- `birthday_wishes`
  - `id` (uuid, primary key)
  - `author_name` (text, not null) — the name of the person leaving the wish
  - `message` (text, not null) — the birthday message
  - `emoji` (text, nullable) — an optional emoji chosen by the visitor
  - `color` (text, nullable) — an optional card color theme chosen by the visitor
  - `created_at` (timestamptz, default now())

3. Security
- Enable RLS on `birthday_wishes`.
- Allow anon + authenticated CRUD because the data is intentionally public/shared
  (a public birthday wishes wall with no sign-in).
- `USING (true)` / `WITH CHECK (true)` is acceptable here because the table is
  intentionally public.

4. Notes
- No user_id column and no auth.users reference — this is a no-auth app.
- An index on created_at (desc) supports the wishes-wall display order.
*/

CREATE TABLE IF NOT EXISTS birthday_wishes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_name text NOT NULL,
  message text NOT NULL,
  emoji text,
  color text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE birthday_wishes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_wishes" ON birthday_wishes;
CREATE POLICY "anon_select_wishes" ON birthday_wishes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_wishes" ON birthday_wishes;
CREATE POLICY "anon_insert_wishes" ON birthday_wishes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_wishes" ON birthday_wishes;
CREATE POLICY "anon_delete_wishes" ON birthday_wishes FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_birthday_wishes_created_at
  ON birthday_wishes (created_at DESC);
