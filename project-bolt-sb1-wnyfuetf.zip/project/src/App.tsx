import { useState, useCallback } from 'react';
import Background from './components/Background';
import Confetti from './components/Confetti';
import FloatingPetals from './components/FloatingPetals';
import PinStep from './components/steps/PinStep';
import HeartsStep from './components/steps/HeartsStep';
import SurpriseStep from './components/steps/SurpriseStep';
import ReadyStep from './components/steps/ReadyStep';
import WishStep from './components/steps/WishStep';
import CelebrateStep from './components/steps/CelebrateStep';
import CandlesStep from './components/steps/CandlesStep';
import FinalStep from './components/steps/FinalStep';

type Step = 'pin' | 'hearts' | 'surprise' | 'ready' | 'wish' | 'celebrate' | 'candles' | 'final';

const STEP_ORDER: Step[] = [
  'pin',
  'hearts',
  'surprise',
  'ready',
  'wish',
  'celebrate',
  'candles',
  'final',
];

const STEP_BG: Record<Step, number> = {
  pin: 1,
  hearts: 2,
  surprise: 3,
  ready: 4,
  wish: 5,
  celebrate: 6,
  candles: 7,
  final: 8,
};

export default function App() {
  const [step, setStep] = useState<Step>('pin');
  const [confettiKey, setConfettiKey] = useState(0);

  const next = useCallback(() => {
    setConfettiKey((k) => k + 1);
    setStep((s) => {
      const idx = STEP_ORDER.indexOf(s);
      return STEP_ORDER[Math.min(idx + 1, STEP_ORDER.length - 1)];
    });
  }, []);

  const stepIndex = STEP_ORDER.indexOf(step);

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Background step={STEP_BG[step]} />
      <FloatingPetals count={12} />

      {/* Confetti on step transitions (not on pin) */}
      {step !== 'pin' && step !== 'hearts' && (
        <Confetti key={confettiKey} count={60} duration={4000} />
      )}

      {/* Progress dots */}
      {step !== 'pin' && step !== 'final' && (
        <div className="fixed left-1/2 top-4 z-40 flex -translate-x-1/2 gap-1.5">
          {STEP_ORDER.slice(0, -1).map((s, i) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i <= stepIndex ? 'w-6 bg-rose-500' : 'w-1.5 bg-ink-200'
              }`}
            />
          ))}
        </div>
      )}

      <main className="relative z-10">
        {step === 'pin' && <PinStep onNext={next} />}
        {step === 'hearts' && <HeartsStep onNext={next} />}
        {step === 'surprise' && <SurpriseStep onNext={next} />}
        {step === 'ready' && <ReadyStep onNext={next} />}
        {step === 'wish' && <WishStep onNext={next} />}
        {step === 'celebrate' && <CelebrateStep onNext={next} />}
        {step === 'candles' && <CandlesStep onNext={next} />}
        {step === 'final' && <FinalStep />}
      </main>
    </div>
  );
}
