import { useRef, useState, useCallback } from 'react';

type Tilt = {
  ref: React.RefObject<HTMLDivElement>;
  style: React.CSSProperties;
  onMouseMove: (e: React.MouseEvent) => void;
  onMouseLeave: () => void;
};

export function useTilt3D(max = 18): Tilt {
  const ref = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<React.CSSProperties>({});

  const onMouseMove = useCallback(
    (e: React.MouseEvent) => {
      const el = ref.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width - 0.5;
      const py = (e.clientY - rect.top) / rect.height - 0.5;
      const rotateY = px * max * 2;
      const rotateX = -py * max * 2;
      setStyle({
        transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(0)`,
        transition: 'transform 0.1s ease-out',
      });
    },
    [max]
  );

  const onMouseLeave = useCallback(() => {
    setStyle({
      transform: 'rotateX(0deg) rotateY(0deg) translateZ(0)',
      transition: 'transform 0.5s ease-out',
    });
  }, []);

  return { ref, style, onMouseMove, onMouseLeave };
}
