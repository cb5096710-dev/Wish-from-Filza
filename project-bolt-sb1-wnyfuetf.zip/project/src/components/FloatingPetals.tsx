import { useMemo } from 'react';

type Petal = {
  id: number;
  left: number;
  delay: number;
  duration: number;
  size: number;
  drift: number;
  color: string;
  rotate: number;
};

const COLORS = ['#ffc9d3', '#ffa0b1', '#f3d9a8', '#d8b4fe', '#fed7aa', '#ffe4e8'];

export default function FloatingPetals({ count = 14 }: { count?: number }) {
  const petals = useMemo<Petal[]>(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 10,
        duration: 8 + Math.random() * 8,
        size: 10 + Math.random() * 14,
        drift: (Math.random() - 0.5) * 200,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        rotate: Math.random() * 360,
      })),
    [count]
  );

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden" style={{ zIndex: 1 }}>
      {petals.map((p) => (
        <div
          key={p.id}
          className="absolute top-0"
          style={{
            left: `${p.left}%`,
            animation: `petal-fall ${p.duration}s linear ${p.delay}s infinite`,
            ['--drift' as string]: `${p.drift}px`,
          }}
        >
          <svg
            width={p.size}
            height={p.size}
            viewBox="0 0 24 24"
            style={{ transform: `rotate(${p.rotate}deg)` }}
          >
            <path
              d="M12 2 C 8 6 8 14 12 22 C 16 14 16 6 12 2 Z"
              fill={p.color}
              opacity={0.85}
            />
          </svg>
        </div>
      ))}
    </div>
  );
}
