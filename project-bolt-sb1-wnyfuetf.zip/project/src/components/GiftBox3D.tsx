import { useState } from 'react';
import { useTilt3D } from '../hooks/useTilt3D';

type Props = {
  color: string;
  ribbon: string;
  onOpen?: () => void;
  className?: string;
  size?: number;
};

export default function GiftBox3D({
  color,
  ribbon,
  onOpen,
  className = '',
  size = 160,
}: Props) {
  const [opened, setOpened] = useState(false);
  const tilt = useTilt3D(15);

  const toggle = () => {
    const next = !opened;
    setOpened(next);
    if (next && onOpen) onOpen();
  };

  const h = size;
  const w = size;

  return (
    <div className={`perspective ${className}`}>
      <div
        ref={tilt.ref}
        className="preserve-3d relative cursor-pointer transition-transform"
        style={{ width: w, height: h + 40, ...tilt.style }}
        onMouseMove={tilt.onMouseMove}
        onMouseLeave={tilt.onMouseLeave}
        onClick={toggle}
      >
        {/* Box body (front face) */}
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-md shadow-xl"
          style={{
            width: w,
            height: h,
            background: `linear-gradient(135deg, ${color}, ${color}dd)`,
            transform: 'translateZ(20px)',
          }}
        >
          {/* Vertical ribbon */}
          <div
            className="absolute left-1/2 top-0 h-full w-6 -translate-x-1/2"
            style={{ background: ribbon }}
          />
          {/* Highlight */}
          <div className="absolute inset-0 rounded-md bg-gradient-to-br from-white/30 via-transparent to-transparent" />
          {/* Polka dots */}
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: `radial-gradient(circle, rgba(255,255,255,0.6) 2px, transparent 3px)`,
              backgroundSize: '20px 20px',
            }}
          />
        </div>

        {/* Lid */}
        <div
          className="preserve-3d absolute left-1/2 top-1/2"
          style={{
            width: w + 16,
            height: 28,
            transform: `translate(-50%, -50%) translateY(-${h / 2 - 14}px) translateZ(40px) ${
              opened ? 'rotateX(-110deg) translateY(-4px)' : 'rotateX(0deg)'
            }`,
            transformOrigin: 'center back',
            transition: 'transform 0.7s cubic-bezier(0.34, 1.56, 0.64, 1)',
          }}
        >
          <div
            className="absolute inset-0 rounded-md shadow-lg"
            style={{ background: `linear-gradient(135deg, ${color}, ${color}cc)` }}
          />
          {/* Lid ribbon */}
          <div
            className="absolute left-1/2 top-0 h-full w-6 -translate-x-1/2"
            style={{ background: ribbon }}
          />
          {/* Bow */}
          <div
            className="absolute left-1/2 -top-6 -translate-x-1/2"
            style={{ transform: 'translateZ(10px)' }}
          >
            <div className="flex gap-1">
              <div
                className="h-6 w-6 rounded-full"
                style={{ background: ribbon, boxShadow: '0 2px 6px rgba(0,0,0,0.2)' }}
              />
              <div
                className="h-6 w-6 rounded-full"
                style={{ background: ribbon, boxShadow: '0 2px 6px rgba(0,0,0,0.2)' }}
              />
            </div>
            <div
              className="mx-auto -mt-4 h-4 w-4 rounded-full"
              style={{ background: ribbon, boxShadow: '0 2px 6px rgba(0,0,0,0.2)' }}
            />
          </div>
        </div>

        {/* Glow under box */}
        <div
          className="absolute left-1/2 top-full -translate-x-1/2 -translate-y-1/2 rounded-[50%] blur-xl"
          style={{
            width: w * 0.9,
            height: 20,
            background: 'rgba(0,0,0,0.15)',
            transform: 'translateZ(0)',
          }}
        />

        {/* Sparkles when opened */}
        {opened && (
          <div className="pointer-events-none absolute inset-0">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="absolute left-1/2 top-1/2"
                style={{
                  animation: `burst-out 1s ease-out ${i * 0.08}s forwards`,
                  ['--drift' as string]: `${(i - 4) * 20}px`,
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#ffe4e8">
                  <path d="M12 0 L13.5 9 L22 12 L13.5 15 L12 24 L10.5 15 L2 12 L10.5 9 Z" />
                </svg>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
