import { useEffect, useState } from 'react';
import { Heart, ArrowRight } from 'lucide-react';
import { useTilt3D } from '../../hooks/useTilt3D';
import Sparkles from '../Sparkles';

const LINES = [
  'Today is not just any day.',
  'It is the day someone wonderful came into the world.',
  'Someone kind, someone funny, someone rare.',
  'And because of that, the world has been a little brighter ever since.',
  'So here is a wish, wrapped in all my love —',
  'May this year be kinder than the last,',
  'may your laughter be louder,',
  'may your worries be smaller,',
  'and may every good thing find its way to you.',
  'Happy Birthday, my dear friend.',
];

export default function WishStep({ onNext }: { onNext: () => void }) {
  const [visible, setVisible] = useState(0);
  const tilt = useTilt3D(8);

  useEffect(() => {
    if (visible >= LINES.length) return;
    const t = setTimeout(() => setVisible((v) => v + 1), 700);
    return () => clearTimeout(t);
  }, [visible]);

  return (
    <div className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-2xl">
        <div className="mb-8 text-center" style={{ animation: 'fade-up 0.7s ease-out' }}>
          <div className="perspective mx-auto mb-5 inline-block">
            <div
              className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/60 shadow-lg backdrop-blur-sm"
              style={{ animation: 'float-y-3d 4s ease-in-out infinite' }}
            >
              <Heart className="h-7 w-7 text-rose-500" fill="currentColor" />
            </div>
          </div>
          <p className="font-script text-2xl text-rose-400">a wish for you</p>
          <h1 className="mt-1 font-display text-3xl font-bold text-ink-800 sm:text-4xl">
            Your Birthday Wish
          </h1>
        </div>

        <div className="perspective">
          <div
            ref={tilt.ref}
            className="glass preserve-3d relative rounded-3xl p-8 shadow-xl sm:p-10"
            style={tilt.style}
            onMouseMove={tilt.onMouseMove}
            onMouseLeave={tilt.onMouseLeave}
          >
            <Sparkles count={12} />

            <div className="relative space-y-4" style={{ transform: 'translateZ(40px)' }}>
              {LINES.map((line, i) => (
                <p
                  key={i}
                  className={`font-display text-lg leading-relaxed transition-all duration-500 sm:text-xl ${
                    i < visible
                      ? 'opacity-100 translate-y-0'
                      : 'opacity-0 translate-y-3'
                  } ${i === LINES.length - 1 ? 'font-bold text-rose-500 text-2xl sm:text-3xl' : 'text-ink-700'}`}
                >
                  {line}
                </p>
              ))}
            </div>

            {visible >= LINES.length && (
              <div
                className="mt-10 text-center"
                style={{ animation: 'fade-up 0.6s ease-out', transform: 'translateZ(50px)' }}
              >
                <button
                  onClick={onNext}
                  className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-8 py-3.5 font-semibold text-white shadow-lg shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
                >
                  Let's celebrate
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
