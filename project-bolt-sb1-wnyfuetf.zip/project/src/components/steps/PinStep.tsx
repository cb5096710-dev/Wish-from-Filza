import { useState } from 'react';
import { Lock, Delete, Sparkles } from 'lucide-react';
import { useTilt3D } from '../../hooks/useTilt3D';
import Sparkles2 from '../Sparkles';

const CORRECT_PIN = '1234';

export default function PinStep({ onNext }: { onNext: () => void }) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [shake, setShake] = useState(false);
  const [success, setSuccess] = useState(false);
  const tilt = useTilt3D(12);

  const press = (digit: string) => {
    if (pin.length >= 4 || success) return;
    const next = pin + digit;
    setPin(next);
    setError(null);

    if (next.length === 4) {
      setTimeout(() => {
        if (next === CORRECT_PIN) {
          setSuccess(true);
          setTimeout(() => onNext(), 900);
        } else {
          setError('Oops! You entered the password wrong. Try another one.');
          setShake(true);
          setTimeout(() => setShake(false), 500);
          setTimeout(() => setPin(''), 600);
        }
      }, 150);
    }
  };

  const backspace = () => {
    setPin((p) => p.slice(0, -1));
    setError(null);
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div
        className="w-full max-w-sm"
        style={{ animation: 'fade-up 0.7s ease-out' }}
      >
        <div className="mb-8 text-center">
          <div className="perspective mx-auto mb-5 inline-block">
            <div
              className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/60 shadow-lg backdrop-blur-sm"
              style={{ animation: 'float-y-3d 4s ease-in-out infinite' }}
            >
              <Lock className="h-8 w-8 text-rose-500" strokeWidth={1.5} />
            </div>
          </div>
          <p className="font-script text-2xl text-rose-400">shh... a little secret</p>
          <h1 className="mt-1 font-display text-3xl font-bold text-ink-800">
            Enter the PIN
          </h1>
          <p className="mt-2 text-sm text-ink-500">
            Only the right 4 digits open the door
          </p>
        </div>

        <div className="perspective">
          <div
            ref={tilt.ref}
            className={`glass preserve-3d relative rounded-3xl p-6 shadow-xl ${
              shake ? 'animate-shake' : ''
            } ${success ? '' : ''}`}
            style={tilt.style}
            onMouseMove={tilt.onMouseMove}
            onMouseLeave={tilt.onMouseLeave}
          >
            {success && <Sparkles2 count={20} />}

            {/* Dots */}
            <div className="mb-6 flex justify-center gap-3" style={{ transform: 'translateZ(40px)' }}>
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={`h-4 w-4 rounded-full border-2 transition-all duration-200 ${
                    pin.length > i
                      ? 'scale-110 border-rose-500 bg-rose-500'
                      : 'border-ink-200 bg-white/40'
                  }`}
                  style={
                    pin.length > i
                      ? { animation: 'pop 0.3s ease-out' }
                      : undefined
                  }
                />
              ))}
            </div>

            {error && (
              <div
                className="mb-4 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-center text-sm font-medium text-rose-600"
                style={{ animation: 'fade-in 0.3s ease-out', transform: 'translateZ(30px)' }}
              >
                {error}
              </div>
            )}

            {success && (
              <div
                className="mb-4 rounded-2xl border border-mint-200 bg-mint-50 px-4 py-3 text-center text-sm font-medium text-mint-600"
                style={{ animation: 'bounce-in 0.5s ease-out', transform: 'translateZ(30px)' }}
              >
                That's it! Opening the door...
              </div>
            )}

            {/* Keypad */}
            <div
              className="grid grid-cols-3 gap-3"
              style={{ transform: 'translateZ(30px)' }}
            >
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                <button
                  key={d}
                  onClick={() => press(d)}
                  disabled={success}
                  className="group relative flex h-16 items-center justify-center overflow-hidden rounded-2xl bg-white/70 font-display text-2xl font-semibold text-ink-800 shadow-sm transition-all hover:bg-white hover:shadow-md active:scale-95 disabled:opacity-50"
                >
                  <span className="relative z-10">{d}</span>
                  <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/60 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
                </button>
              ))}
              <div className="flex h-16 items-center justify-center">
                <Sparkles className="h-5 w-5 text-rose-300" />
              </div>
              <button
                onClick={() => press('0')}
                disabled={success}
                className="group relative flex h-16 items-center justify-center overflow-hidden rounded-2xl bg-white/70 font-display text-2xl font-semibold text-ink-800 shadow-sm transition-all hover:bg-white hover:shadow-md active:scale-95 disabled:opacity-50"
              >
                <span className="relative z-10">0</span>
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/60 to-transparent transition-transform duration-500 group-hover:translate-x-full" />
              </button>
              <button
                onClick={backspace}
                disabled={success}
                className="flex h-16 items-center justify-center rounded-2xl bg-white/70 text-ink-500 shadow-sm transition-all hover:bg-white hover:shadow-md active:scale-95 disabled:opacity-50"
                aria-label="Delete"
              >
                <Delete className="h-5 w-5" />
              </button>
            </div>

            <p className="mt-5 text-center text-xs text-ink-400">
              Hint: it is 1-2-3-4
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
