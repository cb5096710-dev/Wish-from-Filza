import { useState } from 'react';
import { ArrowRight, Sparkles, Cake, Star } from 'lucide-react';
import { useTilt3D } from '../../hooks/useTilt3D';

type Phase = 'intro' | 'decor' | 'cake';

export default function CelebrateStep({ onNext }: { onNext: () => void }) {
  const [phase, setPhase] = useState<Phase>('intro');

  return (
    <div className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-2xl text-center">
        {phase === 'intro' && (
          <div style={{ animation: 'fade-up 0.7s ease-out' }}>
            <div className="perspective mx-auto mb-6 inline-block">
              <div
                className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white/60 shadow-lg backdrop-blur-sm"
                style={{ animation: 'float-y-3d 4s ease-in-out infinite' }}
              >
                <Sparkles className="h-10 w-10 text-rose-500" strokeWidth={1.5} />
              </div>
            </div>
            <p className="font-script text-2xl text-rose-400">the party starts now</p>
            <h1 className="mt-1 font-display text-4xl font-bold text-ink-800 sm:text-5xl">
              Let's celebrate your birthday!
            </h1>
            <p className="mt-4 text-lg text-ink-600">
              First, let's set up the decor. Then we'll bring out the cake.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <button
                onClick={() => setPhase('decor')}
                className="group relative overflow-hidden rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-4 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
              >
                <span className="relative z-10">Decor</span>
                <div className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-700 group-hover:translate-x-full" />
              </button>
              <span className="text-sm text-ink-400">or</span>
              <button
                disabled
                className="cursor-not-allowed rounded-full border border-ink-200 bg-white/40 px-10 py-4 font-medium text-ink-300"
              >
                <span className="flex items-center gap-2">
                  <Cake className="h-5 w-5" />
                  Cake
                </span>
              </button>
            </div>
            <p className="mt-4 text-xs text-ink-400">Set up the decor first to unlock the cake</p>
          </div>
        )}

        {phase === 'decor' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <DecorScene />
            <div className="mt-10" style={{ animation: 'fade-up 0.6s ease-out 1s both' }}>
              <p className="mb-4 font-script text-2xl text-rose-400">looks beautiful, right?</p>
              <button
                onClick={() => setPhase('cake')}
                className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-4 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
              >
                <Cake className="h-5 w-5" />
                Now bring the cake
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        )}

        {phase === 'cake' && (
          <div style={{ animation: 'fade-in 0.5s ease-out' }}>
            <DecorScene compact />
            <div className="perspective mt-6">
              <div style={{ animation: 'scale-in 0.7s ease-out 0.3s both' }}>
                <CakeScene3D />
              </div>
            </div>
            <div className="mt-10" style={{ animation: 'fade-up 0.6s ease-out 1.2s both' }}>
              <p className="mb-4 font-script text-2xl text-rose-400">a cake just for you</p>
              <button
                onClick={onNext}
                className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-4 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
              >
                Time to blow the candles
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DecorScene({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`relative ${compact ? 'h-32' : 'h-72'} w-full`}>
      <svg className="absolute inset-x-0 top-0 h-full w-full" viewBox="0 0 400 200" preserveAspectRatio="xMidYMid meet">
        <path d="M 20 30 Q 200 60 380 30" stroke="rgba(0,0,0,0.2)" strokeWidth="1.5" fill="none" />
        {Array.from({ length: 9 }).map((_, i) => {
          const colors = ['#f54267', '#e3a44f', '#4cbe88', '#3a72f5', '#a855f7', '#fb923c', '#f54267', '#4cbe88', '#e3a44f'];
          const x = 30 + i * 42;
          const y = 30 + Math.sin((i / 8) * Math.PI) * 25;
          return (
            <g key={i} style={{ animation: `sway ${3 + (i % 3)}s ease-in-out ${i * 0.2}s infinite`, transformOrigin: `${x}px ${y}px` }}>
              <path d={`M ${x} ${y} L ${x - 12} ${y + 28} L ${x + 12} ${y + 28} Z`} fill={colors[i]} />
            </g>
          );
        })}
      </svg>

      {!compact &&
        [0, 1, 2, 3, 4].map((i) => {
          const colors = [
            { body: '#ff6b85', hi: '#ffa0b1' },
            { body: '#e3a44f', hi: '#f3d9a8' },
            { body: '#4cbe88', hi: '#7fd6ab' },
            { body: '#5b94ff', hi: '#8bb8ff' },
            { body: '#c084fc', hi: '#d8b4fe' },
          ];
          const c = colors[i];
          const left = 15 + i * 18;
          return (
            <div
              key={i}
              className="absolute"
              style={{
                left: `${left}%`,
                bottom: 0,
                animation: `float ${4 + i * 0.5}s ease-in-out ${i * 0.3}s infinite`,
              }}
            >
              <svg width="50" height="65" viewBox="0 0 60 80">
                <defs>
                  <radialGradient id={`dbal-${i}`} cx="35%" cy="30%">
                    <stop offset="0%" stopColor={c.hi} />
                    <stop offset="100%" stopColor={c.body} />
                  </radialGradient>
                </defs>
                <ellipse cx="30" cy="32" rx="22" ry="26" fill={`url(#dbal-${i})`} />
                <ellipse cx="22" cy="20" rx="5" ry="8" fill="rgba(255,255,255,0.4)" />
                <path d="M30 58 L27 62 L33 62 Z" fill={c.body} />
                <path d="M30 62 Q26 70 30 78 Q34 70 30 62" stroke="rgba(0,0,0,0.2)" strokeWidth="1" fill="none" />
              </svg>
            </div>
          );
        })}

      {!compact &&
        Array.from({ length: 20 }).map((_, i) => {
          const colors = ['#f54267', '#e3a44f', '#4cbe88', '#3a72f5', '#a855f7'];
          return (
            <div
              key={i}
              className="absolute rounded-full"
              style={{
                left: `${(i * 37) % 100}%`,
                top: `${30 + (i * 13) % 50}%`,
                width: '6px',
                height: '6px',
                background: colors[i % colors.length],
                animation: `twinkle ${2 + (i % 3)}s ease-in-out ${i * 0.1}s infinite`,
              }}
            />
          );
        })}

      {!compact &&
        Array.from({ length: 6 }).map((_, i) => (
          <Star
            key={i}
            className="absolute text-cream-400"
            style={{
              left: `${10 + i * 15}%`,
              top: `${20 + (i % 3) * 15}%`,
              animation: `twinkle 2s ease-in-out ${i * 0.3}s infinite`,
            } as React.CSSProperties}
            fill="currentColor"
          />
        ))}
    </div>
  );
}

function CakeScene3D() {
  const tilt = useTilt3D(15);
  return (
    <div className="perspective">
      <div
        ref={tilt.ref}
        className="preserve-3d relative mx-auto inline-block"
        style={tilt.style}
        onMouseMove={tilt.onMouseMove}
        onMouseLeave={tilt.onMouseLeave}
      >
        <div className="relative mx-auto w-72">
          {/* Plate */}
          <div
            className="relative mx-auto h-4 w-64 rounded-[50%] bg-gradient-to-b from-ink-700 to-ink-800 shadow-2xl"
            style={{ transform: 'translateZ(2px)' }}
          />
          {/* Cake body */}
          <div className="relative mx-auto -mt-2 w-56" style={{ transform: 'translateZ(20px)' }}>
            {/* Top tier */}
            <div className="relative h-12 rounded-t-2xl bg-gradient-to-b from-cream-300 to-cream-400 shadow-lg">
              <div className="absolute -top-2 left-0 right-0 h-5">
                <svg viewBox="0 0 224 20" className="h-full w-full" preserveAspectRatio="none">
                  <path
                    d="M0 0 L224 0 L224 10 Q212 20 200 10 Q188 20 176 10 Q164 20 152 10 Q140 20 128 10 Q116 20 104 10 Q92 20 80 10 Q68 20 56 10 Q44 20 32 10 Q20 20 8 10 Q4 10 0 10 Z"
                    fill="#fff5f6"
                  />
                </svg>
              </div>
            </div>
            {/* Middle tier */}
            <div className="relative h-20 bg-gradient-to-b from-rose-300 to-rose-400 shadow-lg">
              <div className="absolute inset-0 overflow-hidden">
                {Array.from({ length: 14 }).map((_, i) => {
                  const colors = ['#f54267', '#4cbe88', '#3a72f5', '#e3a44f', '#a855f7'];
                  return (
                    <div
                      key={i}
                      className="absolute rounded-full"
                      style={{
                        left: `${(i * 53) % 100}%`,
                        top: `${(i * 37) % 70 + 15}%`,
                        width: '4px',
                        height: '8px',
                        background: colors[i % colors.length],
                        transform: `rotate(${(i * 47) % 180}deg)`,
                      }}
                    />
                  );
                })}
              </div>
              <p className="absolute inset-0 flex items-center justify-center font-script text-2xl text-white/90">
                for you
              </p>
            </div>
            {/* Bottom tier */}
            <div className="relative h-10 bg-gradient-to-b from-cream-400 to-cream-500 shadow-lg" />
            {/* Bottom frosting */}
            <div className="relative h-6">
              <svg viewBox="0 0 224 24" className="h-full w-full" preserveAspectRatio="none">
                <path
                  d="M0 0 L224 0 L224 12 Q212 24 200 12 Q188 24 176 12 Q164 24 152 12 Q140 24 128 12 Q116 24 104 12 Q92 24 80 12 Q68 24 56 12 Q44 24 32 12 Q20 24 8 12 Q4 12 0 12 Z"
                  fill="#ffe4e8"
                />
              </svg>
            </div>
          </div>
          {/* Shadow */}
          <div
            className="absolute left-1/2 top-full -translate-x-1/2 -translate-y-1/2 rounded-[50%] blur-xl"
            style={{
              width: 220,
              height: 16,
              background: 'rgba(0,0,0,0.15)',
            }}
          />
        </div>
      </div>
    </div>
  );
}
