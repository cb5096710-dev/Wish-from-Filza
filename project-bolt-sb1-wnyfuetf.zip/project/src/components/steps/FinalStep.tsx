import { useState, useEffect } from 'react';
import { Heart, ThumbsUp, Sparkles, Star, Send, Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useTilt3D } from '../../hooks/useTilt3D';
import Sparkles2 from '../Sparkles';

const REACTIONS = [
  { id: 'loved', label: 'Loved it!', icon: Heart, color: 'from-rose-500 to-rose-400' },
  { id: 'liked', label: 'Liked it', icon: ThumbsUp, color: 'from-peach-400 to-cream-500' },
  { id: 'okay', label: "It's okay", icon: Star, color: 'from-sky-400 to-mint-400' },
];

export default function FinalStep() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [reaction, setReaction] = useState<string | null>(null);
  const [hearts, setHearts] = useState<{ id: number; left: number }[]>([]);
  const [bursts, setBursts] = useState(0);
  const tilt = useTilt3D(20);

  useEffect(() => {
    const interval = setInterval(() => {
      setHearts((prev) => [
        ...prev.slice(-12),
        { id: Date.now(), left: Math.random() * 100 },
      ]);
    }, 800);
    return () => clearInterval(interval);
  }, []);

  const submit = async () => {
    if (!reaction) return;
    setSubmitting(true);
    const { error } = await supabase.from('surprise_reactions').insert({
      reaction,
      note: note.trim() || null,
    });
    setSubmitting(false);

    if (error) {
      setError('Could not save your reaction, but thank you anyway!');
      setSubmitted(true);
    } else {
      setBursts((b) => b + 1);
      setSubmitted(true);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center px-6 py-16">
      {/* Floating hearts */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        {hearts.map((h) => (
          <div
            key={h.id}
            className="absolute bottom-0"
            style={{
              left: `${h.left}%`,
              animation: 'heart-float 4s ease-out forwards',
              ['--rot' as string]: `${(Math.random() - 0.5) * 60}deg`,
            }}
          >
            <Heart className="h-6 w-6 text-rose-400/70" fill="currentColor" />
          </div>
        ))}
      </div>

      {/* Sparkle burst on submit */}
      {bursts > 0 && (
        <div className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center">
          {Array.from({ length: 24 }).map((_, i) => (
            <div
              key={`${bursts}-${i}`}
              className="absolute"
              style={{
                transform: `rotate(${(i / 24) * 360}deg)`,
                animation: `sparkle-spin 1s ease-out ${i * 0.02}s forwards`,
              }}
            >
              <div
                className="h-16 w-1.5"
                style={{
                  transformOrigin: 'bottom center',
                  background: ['#f54267', '#e3a44f', '#4cbe88', '#3a72f5', '#a855f7'][i % 5],
                }}
              />
            </div>
          ))}
        </div>
      )}

      <div className="relative w-full max-w-2xl text-center" style={{ animation: 'fade-up 0.7s ease-out' }}>
        {/* 3D Heart */}
        <div className="perspective mx-auto mb-6 inline-block">
          <div
            ref={tilt.ref}
            className="preserve-3d flex h-20 w-20 items-center justify-center rounded-3xl bg-white/60 shadow-lg backdrop-blur-sm"
            style={{ ...tilt.style, animation: 'float-y-3d 4s ease-in-out infinite' }}
            onMouseMove={tilt.onMouseMove}
            onMouseLeave={tilt.onMouseLeave}
          >
            <Heart
              className="h-10 w-10 text-rose-500"
              fill="currentColor"
              style={{ animation: 'heart-beat 1.5s ease-in-out infinite' }}
            />
          </div>
        </div>

        <p className="font-script text-3xl text-rose-400">a surprise from</p>
        <h1 className="mt-1 font-display text-6xl font-black text-gradient-warm sm:text-7xl">
          Filza
        </h1>

        <div className="perspective">
          <div
            className="glass preserve-3d relative mt-8 rounded-3xl p-8 shadow-xl sm:p-10"
            style={{ transform: 'translateZ(0)' }}
          >
            <Sparkles2 count={16} />
            <div className="relative" style={{ transform: 'translateZ(30px)' }}>
              <p className="font-display text-lg leading-relaxed text-ink-700 sm:text-xl">
                This whole little world — the gifts, the cake, the candles, the wishes —
                was made just for you, with a lot of love.
              </p>
              <p className="mt-4 font-display text-lg leading-relaxed text-ink-700 sm:text-xl">
                You matter, more than you know. And today, the world celebrates you.
              </p>
              <p className="mt-6 font-script text-2xl text-rose-500">
                Happy Birthday, from me to you.
              </p>
              <p className="mt-1 text-sm font-medium text-ink-500">— Filza</p>
            </div>
          </div>
        </div>

        {!submitted ? (
          <div className="mt-10" style={{ animation: 'fade-up 0.6s ease-out 0.3s both' }}>
            <p className="font-display text-2xl font-bold text-ink-800">
              Did you like it?
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              {REACTIONS.map((r) => {
                const Icon = r.icon;
                const selected = reaction === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => setReaction(r.id)}
                    className={`group relative flex items-center gap-2 overflow-hidden rounded-full px-6 py-3 font-medium transition-all ${
                      selected
                        ? `bg-gradient-to-r ${r.color} text-white shadow-lg scale-105`
                        : 'bg-white/70 text-ink-700 backdrop-blur-sm hover:bg-white'
                    }`}
                  >
                    <Icon
                      className="h-5 w-5 transition-transform group-hover:scale-125"
                      fill={selected ? 'currentColor' : 'none'}
                    />
                    {r.label}
                    {selected && (
                      <span className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-500 group-hover:translate-x-full" />
                    )}
                  </button>
                );
              })}
            </div>

            {reaction && (
              <div className="mt-6" style={{ animation: 'fade-up 0.4s ease-out' }}>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  maxLength={200}
                  rows={2}
                  placeholder="Want to say something back to Filza? (optional)"
                  className="w-full resize-none rounded-2xl border border-ink-200 bg-white/70 px-4 py-3 text-ink-800 outline-none transition-colors focus:border-rose-300 focus:bg-white"
                />
                <button
                  onClick={submit}
                  disabled={submitting}
                  className="group mt-4 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-8 py-3.5 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95 disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5" />
                      Send to Filza
                    </>
                  )}
                </button>
              </div>
            )}

            {error && <p className="mt-4 text-sm text-rose-500">{error}</p>}
          </div>
        ) : (
          <div
            className="mt-10 rounded-3xl border border-rose-200 bg-white/70 px-8 py-10 shadow-lg backdrop-blur-sm"
            style={{ animation: 'bounce-in 0.6s ease-out' }}
          >
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-rose-100">
              <Sparkles className="h-8 w-8 text-rose-500" />
            </div>
            <p className="font-display text-2xl font-bold text-ink-800">
              Thank you!
            </p>
            <p className="mt-2 text-ink-600">
              Your reaction has been sent. You just made Filza's day.
            </p>
            <p className="mt-6 font-script text-2xl text-rose-400">
              see you next birthday
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
