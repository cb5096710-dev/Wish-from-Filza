import { useState } from 'react';
import { Sparkles, Frown } from 'lucide-react';
import GiftBox3D from '../GiftBox3D';
import Sparkles2 from '../Sparkles';

export default function SurpriseStep({ onNext }: { onNext: () => void }) {
  const [saidNo, setSaidNo] = useState(false);

  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="w-full max-w-lg text-center" style={{ animation: 'fade-up 0.7s ease-out' }}>
        <p className="font-script text-2xl text-rose-400">psst...</p>
        <h1 className="mt-1 font-display text-4xl font-bold text-ink-800 sm:text-5xl">
          I have a surprise for you
        </h1>
        <p className="mt-4 text-lg text-ink-600">Do you wanna see it?</p>

        {/* 3D gift box */}
        <div className="my-10 flex justify-center">
          <div style={{ animation: 'wobble-3d 4s ease-in-out infinite' }}>
            <GiftBox3D color="#f54267" ribbon="#ffe4e8" size={140} />
          </div>
        </div>

        {!saidNo ? (
          <div
            className="flex flex-col items-center justify-center gap-4 sm:flex-row"
            style={{ animation: 'fade-up 0.6s ease-out 0.2s both' }}
          >
            <button
              onClick={onNext}
              className="group relative overflow-hidden rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-4 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
            >
              <span className="relative z-10 flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                Yes!
              </span>
              <div className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-700 group-hover:translate-x-full" />
            </button>
            <button
              onClick={() => setSaidNo(true)}
              className="rounded-full border border-ink-200 bg-white/60 px-10 py-4 font-medium text-ink-600 backdrop-blur-sm transition-colors hover:bg-white"
            >
              No
            </button>
          </div>
        ) : (
          <div
            className="relative"
            style={{ animation: 'fade-up 0.5s ease-out' }}
          >
            <Sparkles2 count={10} />
            <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-white/60 shadow-md backdrop-blur-sm">
              <Frown className="h-8 w-8 text-rose-400" strokeWidth={1.5} />
            </div>
            <p className="font-display text-2xl font-semibold text-ink-700">
              You don't wanna see it?
            </p>
            <p className="mt-2 text-ink-500">
              Are you sure? It is really, really good...
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <button
                onClick={() => setSaidNo(false)}
                className="rounded-full border border-ink-200 bg-white/60 px-8 py-3 font-medium text-ink-600 backdrop-blur-sm transition-colors hover:bg-white"
              >
                Hmm, let me think
              </button>
              <button
                onClick={onNext}
                className="group relative overflow-hidden rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-3.5 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Okay, yes!
                </span>
                <div className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-700 group-hover:translate-x-full" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
