import { Sparkles, PartyPopper } from 'lucide-react';

export default function ReadyStep({ onNext }: { onNext: () => void }) {
  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="w-full max-w-lg text-center" style={{ animation: 'fade-up 0.7s ease-out' }}>
        <div className="perspective mx-auto mb-6 inline-block">
          <div
            className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white/60 shadow-lg backdrop-blur-sm"
            style={{ animation: 'float-y-3d 4s ease-in-out infinite' }}
          >
            <PartyPopper className="h-10 w-10 text-peach-500" strokeWidth={1.5} />
          </div>
        </div>

        <p className="font-script text-2xl text-rose-400">here we go</p>
        <h1 className="mt-1 font-display text-4xl font-bold text-ink-800 sm:text-5xl">
          Are you ready for the surprise?
        </h1>
        <p className="mt-4 text-lg text-ink-600">
          Tap the button below when you are ready to smile.
        </p>

        <div className="mt-10">
          <div className="relative inline-block">
            {/* Orbiting sparkles */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="absolute"
                  style={{
                    ['--orbit-r' as string]: '90px',
                    animation: `orbit ${8 + i}s linear infinite`,
                    animationDelay: `${-i * 1.3}s`,
                  }}
                >
                  <svg
                    width={10 + (i % 3) * 4}
                    height={10 + (i % 3) * 4}
                    viewBox="0 0 24 24"
                    fill={['#f54267', '#e3a44f', '#4cbe88', '#3a72f5', '#a855f7', '#fb923c'][i]}
                  >
                    <path d="M12 0 L13.5 9 L22 12 L13.5 15 L12 24 L10.5 15 L2 12 L10.5 9 Z" />
                  </svg>
                </div>
              ))}
            </div>

            {/* Pulsing rings */}
            <div
              className="pointer-events-none absolute inset-0 rounded-full border-2 border-rose-400"
              style={{ animation: 'ring-pulse 2s ease-out infinite' }}
            />
            <div
              className="pointer-events-none absolute inset-0 rounded-full border-2 border-peach-400"
              style={{ animation: 'ring-pulse 2s ease-out 1s infinite' }}
            />

            <button
              onClick={onNext}
              className="group relative inline-flex overflow-hidden rounded-full bg-gradient-to-r from-rose-500 via-peach-400 to-cream-500 px-12 py-5 font-display text-lg font-bold text-white shadow-2xl shadow-rose-300/50 transition-transform hover:scale-110 active:scale-95"
              style={{ animation: 'glow-ring 2.5s ease-in-out infinite' }}
            >
              <span className="relative z-10 flex items-center gap-2">
                <Sparkles className="h-6 w-6" />
                Ready!
              </span>
              <div className="absolute inset-0 -translate-x-full bg-white/25 transition-transform duration-700 group-hover:translate-x-full" />
            </button>
          </div>
        </div>

        <p className="mt-6 text-sm text-ink-400">
          Take a breath. The fun starts on the next page.
        </p>
      </div>
    </div>
  );
}
