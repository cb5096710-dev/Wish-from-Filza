import { useState } from 'react';
import { ArrowRight, Wind } from 'lucide-react';

const WISHES = [
  {
    title: 'Wish one',
    text: 'May your heart stay as soft and brave as it is today.',
    color: 'from-rose-400 to-rose-500',
    bg: 'bg-rose-50',
    border: 'border-rose-200',
  },
  {
    title: 'Wish two',
    text: 'May laughter find you in every season, especially the quiet ones.',
    color: 'from-peach-400 to-cream-500',
    bg: 'bg-peach-50',
    border: 'border-peach-200',
  },
  {
    title: 'Wish three',
    text: 'May this year bring you something even better than what you wished for.',
    color: 'from-lilac-400 to-rose-400',
    bg: 'bg-lilac-50',
    border: 'border-lilac-200',
  },
];

type Smoke = { id: number; candle: number };

export default function CandlesStep({ onNext }: { onNext: () => void }) {
  const [lit, setLit] = useState<boolean[]>([true, true, true]);
  const [revealed, setRevealed] = useState<boolean[]>([false, false, false]);
  const [blowing, setBlowing] = useState<number | null>(null);
  const [smokes, setSmokes] = useState<Smoke[]>([]);

  const allOut = lit.every((c) => !c);

  const blow = (i: number) => {
    if (!lit[i]) return;
    setBlowing(i);
    // add smoke puffs
    const ids = Array.from({ length: 3 }, (_, k) => ({
      id: Date.now() + k,
      candle: i,
    }));
    setSmokes((prev) => [...prev, ...ids]);
    setTimeout(() => {
      setSmokes((prev) => prev.filter((s) => !ids.includes(s)));
    }, 1500);

    setTimeout(() => {
      setLit((prev) => prev.map((c, idx) => (idx === i ? false : c)));
      setRevealed((prev) => prev.map((r, idx) => (idx === i ? true : r)));
      setBlowing(null);
    }, 600);
  };

  const blowAll = () => {
    lit.forEach((c, i) => {
      if (c) setTimeout(() => blow(i), i * 350);
    });
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-3xl text-center">
        <div className="mb-8" style={{ animation: 'fade-up 0.7s ease-out' }}>
          <p className="font-script text-2xl text-rose-400">make a wish</p>
          <h1 className="mt-1 font-display text-4xl font-bold text-ink-800 sm:text-5xl">
            Blow the Candles
          </h1>
          <p className="mt-4 text-lg text-ink-600">
            Three candles, three wishes. Tap each one to blow it out.
          </p>
        </div>

        {/* 3D Candles */}
        <div className="perspective">
          <div className="relative mb-10 preserve-3d" style={{ transform: 'rotateX(15deg)' }}>
            <div className="flex items-end justify-center gap-8 sm:gap-16">
              {lit.map((isLit, i) => (
                <div key={i} className="relative flex flex-col items-center" style={{ transform: 'translateZ(20px)' }}>
                  {/* Flame */}
                  <div className="relative h-12 w-5">
                    {isLit && (
                      <div
                        className="absolute bottom-0 left-1/2 -translate-x-1/2"
                        style={{
                          animation: blowing === i
                            ? 'float-up-fade 0.6s ease-out forwards'
                            : 'flame-flicker 0.4s ease-in-out infinite',
                        }}
                      >
                        <div className="relative">
                          <div className="h-8 w-4 rounded-full bg-gradient-to-t from-rose-500 via-cream-400 to-cream-200 blur-[1px]" />
                          <div className="absolute bottom-1 left-1/2 h-4 w-2 -translate-x-1/2 rounded-full bg-sky-400 opacity-70 blur-[1px]" />
                          <div className="absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rounded-full bg-cream-200 opacity-60 blur-sm" />
                          {/* Flame glow */}
                          <div className="absolute -inset-3 rounded-full bg-cream-200/40 blur-xl" />
                        </div>
                      </div>
                    )}
                  </div>
                  {/* Wick */}
                  <div className="h-1 w-0.5 bg-ink-700" />
                  {/* Candle body with 3D shading */}
                  <div
                    className={`relative h-24 w-6 cursor-pointer overflow-hidden rounded-md bg-gradient-to-b ${WISHES[i].color} shadow-md transition-transform hover:scale-105`}
                    onClick={() => blow(i)}
                    role="button"
                    aria-label={`Blow candle ${i + 1}`}
                  >
                    {/* Left highlight */}
                    <div className="absolute left-0 top-0 h-full w-1.5 bg-white/40" />
                    {/* Right shadow */}
                    <div className="absolute right-0 top-0 h-full w-1 bg-black/20" />
                    {/* Stripes */}
                    <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_4px,rgba(255,255,255,0.3)_4px,rgba(255,255,255,0.3)_8px)]" />
                  </div>
                  {/* Number */}
                  <div className="mt-2 rounded-full bg-white/70 px-3 py-0.5 text-xs font-medium text-ink-600 backdrop-blur-sm">
                    {i + 1}
                  </div>

                  {/* Smoke puffs */}
                  {smokes.filter((s) => s.candle === i).map((s, k) => (
                    <div
                      key={s.id}
                      className="absolute top-0 left-1/2 h-3 w-3 rounded-full bg-ink-200/60"
                      style={{
                        ['--drift' as string]: `${(k - 1) * 12}px`,
                        animation: `smoke-rise 1.5s ease-out ${k * 0.1}s forwards`,
                      }}
                    />
                  ))}
                </div>
              ))}
            </div>

            {/* Glow */}
            {lit.some((c) => c) && (
              <div
                className="absolute -top-8 left-1/2 h-32 w-72 -translate-x-1/2 rounded-full bg-cream-200/40 blur-2xl"
                style={{ animation: 'pulse-soft 2s ease-in-out infinite' }}
              />
            )}
          </div>
        </div>

        {/* Blow all button */}
        {!allOut && (
          <button
            onClick={blowAll}
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-sky-400 to-mint-400 px-8 py-3 font-semibold text-white shadow-lg shadow-sky-200/50 transition-transform hover:scale-105 active:scale-95"
          >
            <Wind className="h-5 w-5" />
            Blow all candles
          </button>
        )}

        {/* Revealed wishes */}
        <div className="mt-10 space-y-4">
          {revealed.map((r, i) =>
            r ? (
              <div
                key={i}
                className={`rounded-2xl border ${WISHES[i].border} ${WISHES[i].bg} px-6 py-4 shadow-sm`}
                style={{ animation: 'fade-up 0.5s ease-out' }}
              >
                <p className="font-display text-sm font-semibold uppercase tracking-wider text-ink-400">
                  {WISHES[i].title}
                </p>
                <p className="mt-1 font-display text-lg text-ink-800">{WISHES[i].text}</p>
              </div>
            ) : null
          )}
        </div>

        {allOut && (
          <div className="mt-10" style={{ animation: 'fade-up 0.6s ease-out' }}>
            <p className="mb-4 font-script text-2xl text-rose-400">
              all your wishes are on their way...
            </p>
            <button
              onClick={onNext}
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-peach-400 px-10 py-4 font-semibold text-white shadow-xl shadow-rose-300/40 transition-transform hover:scale-105 active:scale-95"
            >
              See your surprise
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
