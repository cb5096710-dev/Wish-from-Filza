import { useState, useRef, useEffect } from 'react';
import { Heart } from 'lucide-react';

const COUNT = 5;
const RADIUS = 130;

type Point = { x: number; y: number };

function getHeartPositions(centerX: number, centerY: number): Point[] {
  return Array.from({ length: COUNT }, (_, i) => {
    const angle = (i / COUNT) * Math.PI * 2 - Math.PI / 2;
    return {
      x: centerX + RADIUS * Math.cos(angle),
      y: centerY + RADIUS * Math.sin(angle),
    };
  });
}

export default function HeartsStep({ onNext }: { onNext: () => void }) {
  const [connected, setConnected] = useState<number[]>([]);
  const [dragging, setDragging] = useState(false);
  const [mouse, setMouse] = useState<Point | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [center, setCenter] = useState<Point>({ x: 200, y: 200 });
  const [trail, setTrail] = useState<{ id: number; x: number; y: number }[]>([]);
  const trailId = useRef(0);

  useEffect(() => {
    const measure = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setCenter({ x: rect.width / 2, y: rect.height / 2 });
      }
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  const hearts = getHeartPositions(center.x, center.y);

  const handleStart = (clientX: number, clientY: number) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setCenter({ x: rect.width / 2, y: rect.height / 2 });
    }
    setDragging(true);
    setMouse({ x: clientX, y: clientY });
    if (connected.length === 0) {
      setConnected([0]);
    }
  };

  const handleMove = (clientX: number, clientY: number) => {
    if (!dragging) return;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    setMouse({ x, y });

    trailId.current += 1;
    const id = trailId.current;
    setTrail((prev) => [...prev.slice(-12), { id, x, y }]);
    setTimeout(() => {
      setTrail((prev) => prev.filter((t) => t.id !== id));
    }, 600);

    const nextIdx = connected.length;
    if (nextIdx < COUNT) {
      const target = hearts[nextIdx];
      const dist = Math.hypot(x - target.x, y - target.y);
      if (dist < 45) {
        setConnected((prev) => [...prev, nextIdx]);
      }
    }
  };

  useEffect(() => {
    if (connected.length === COUNT) {
      const t = setTimeout(() => onNext(), 900);
      return () => clearTimeout(t);
    }
  }, [connected, onNext]);

  const handleEnd = () => {
    setDragging(false);
    setMouse(null);
    setTrail([]);
    setConnected((prev) => (prev.length < COUNT ? [] : prev));
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-6">
      <div className="w-full max-w-md" style={{ animation: 'fade-up 0.7s ease-out' }}>
        <div className="mb-6 text-center">
          <p className="font-script text-2xl text-rose-400">a little ritual</p>
          <h1 className="mt-1 font-display text-3xl font-bold text-ink-800">
            Connect the Hearts
          </h1>
          <p className="mt-2 text-sm text-ink-500">
            Draw a line through all 5 hearts in a circle to continue
          </p>
        </div>

        <div
          ref={containerRef}
          className="glass perspective relative aspect-square w-full touch-none overflow-hidden rounded-3xl shadow-xl"
          onMouseDown={(e) => handleStart(e.clientX, e.clientY)}
          onMouseMove={(e) => handleMove(e.clientX, e.clientY)}
          onMouseUp={handleEnd}
          onMouseLeave={handleEnd}
          onTouchStart={(e) => {
            const t = e.touches[0];
            handleStart(t.clientX, t.clientY);
          }}
          onTouchMove={(e) => {
            const t = e.touches[0];
            handleMove(t.clientX, t.clientY);
          }}
          onTouchEnd={handleEnd}
        >
          <svg className="absolute inset-0 h-full w-full pointer-events-none">
            {connected.length > 1 &&
              connected.slice(1).map((idx, i) => {
                const from = hearts[connected[i]];
                const to = hearts[idx];
                return (
                  <line
                    key={i}
                    x1={from.x}
                    y1={from.y}
                    x2={to.x}
                    y2={to.y}
                    stroke="#f54267"
                    strokeWidth="4"
                    strokeLinecap="round"
                    style={{ animation: 'fade-in 0.2s ease-out' }}
                  />
                );
              })}
            {dragging && connected.length > 0 && connected.length < COUNT && mouse && (
              <line
                x1={hearts[connected[connected.length - 1]].x}
                y1={hearts[connected[connected.length - 1]].y}
                x2={mouse.x}
                y2={mouse.y}
                stroke="#ffa0b1"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray="6 6"
              />
            )}
            {connected.length === COUNT && (
              <line
                x1={hearts[COUNT - 1].x}
                y1={hearts[COUNT - 1].y}
                x2={hearts[0].x}
                y2={hearts[0].y}
                stroke="#f54267"
                strokeWidth="4"
                strokeLinecap="round"
                style={{ animation: 'fade-in 0.3s ease-out' }}
              />
            )}
          </svg>

          {trail.map((t) => (
            <div
              key={t.id}
              className="absolute h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-rose-400"
              style={{
                left: t.x,
                top: t.y,
                animation: 'sparkle-spin 0.6s ease-out forwards',
              }}
            />
          ))}

          {hearts.map((pos, i) => {
            const isOn = connected.includes(i);
            const isNext = connected.length === i;
            return (
              <div
                key={i}
                className="absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: pos.x, top: pos.y, perspective: '400px' }}
              >
                <div
                  className={`preserve-3d relative flex h-12 w-12 items-center justify-center rounded-full transition-all duration-300 ${
                    isOn
                      ? 'bg-rose-500 text-white scale-110 shadow-lg shadow-rose-300'
                      : isNext
                      ? 'bg-white text-rose-400 scale-110 ring-4 ring-rose-300/50'
                      : 'bg-white/70 text-rose-300'
                  }`}
                  style={
                    isOn
                      ? { animation: 'pop 0.4s ease-out, heart-beat 1.5s ease-in-out 0.4s infinite' }
                      : isNext
                      ? { animation: 'tilt-idle 3s ease-in-out infinite' }
                      : { animation: 'float-y-3d 4s ease-in-out infinite' }
                  }
                >
                  <Heart
                    className="h-6 w-6"
                    fill={isOn ? 'currentColor' : 'none'}
                    strokeWidth={1.5}
                  />
                  {isOn && (
                    <div
                      className="absolute inset-0 rounded-full border-2 border-rose-400"
                      style={{ animation: 'ring-pulse 1.5s ease-out infinite' }}
                    />
                  )}
                </div>
              </div>
            );
          })}

          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/70 px-4 py-1.5 text-xs font-medium text-ink-600 backdrop-blur-sm">
            {connected.length} / {COUNT} hearts
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-ink-400">
          Press and drag from one heart to the next, around the circle
        </p>
      </div>
    </div>
  );
}
