import { useMemo } from 'react';

type Theme = {
  name: string;
  base: string;
  orbs: { color: string; pos: string; size: string; delay: string }[];
  accent: string;
};

const THEMES: Record<number, Theme> = {
  1: {
    name: 'rose',
    base: 'bg-gradient-to-br from-rose-100 via-rose-200 to-lilac-100',
    orbs: [
      { color: 'bg-rose-300/50', pos: 'left-[-10%] top-[10%]', size: 'h-72 w-72', delay: '0s' },
      { color: 'bg-lilac-200/50', pos: 'right-[-5%] top-[30%]', size: 'h-80 w-80', delay: '1s' },
      { color: 'bg-rose-200/40', pos: 'bottom-[5%] left-[20%]', size: 'h-64 w-64', delay: '2s' },
    ],
    accent: '#f54267',
  },
  2: {
    name: 'lilac',
    base: 'bg-gradient-to-br from-lilac-100 via-rose-50 to-peach-100',
    orbs: [
      { color: 'bg-lilac-300/50', pos: 'left-[-10%] top-[20%]', size: 'h-80 w-80', delay: '0.5s' },
      { color: 'bg-rose-200/50', pos: 'right-[-10%] bottom-[10%]', size: 'h-72 w-72', delay: '1.5s' },
      { color: 'bg-peach-200/40', pos: 'top-[40%] left-[40%]', size: 'h-64 w-64', delay: '2.5s' },
    ],
    accent: '#a855f7',
  },
  3: {
    name: 'peach',
    base: 'bg-gradient-to-br from-peach-100 via-cream-100 to-rose-100',
    orbs: [
      { color: 'bg-peach-300/50', pos: 'right-[-10%] top-[10%]', size: 'h-80 w-80', delay: '0s' },
      { color: 'bg-cream-200/50', pos: 'left-[-5%] bottom-[15%]', size: 'h-72 w-72', delay: '1s' },
      { color: 'bg-rose-200/40', pos: 'top-[50%] right-[30%]', size: 'h-64 w-64', delay: '2s' },
    ],
    accent: '#f97316',
  },
  4: {
    name: 'mint',
    base: 'bg-gradient-to-br from-mint-100 via-sky-50 to-lilac-100',
    orbs: [
      { color: 'bg-mint-200/50', pos: 'left-[-10%] top-[15%]', size: 'h-80 w-80', delay: '0.5s' },
      { color: 'bg-sky-200/50', pos: 'right-[-10%] bottom-[20%]', size: 'h-72 w-72', delay: '1.5s' },
      { color: 'bg-lilac-200/40', pos: 'top-[40%] left-[35%]', size: 'h-64 w-64', delay: '2.5s' },
    ],
    accent: '#2aa36d',
  },
  5: {
    name: 'sky',
    base: 'bg-gradient-to-br from-sky-100 via-lilac-50 to-rose-100',
    orbs: [
      { color: 'bg-sky-300/50', pos: 'right-[-10%] top-[20%]', size: 'h-80 w-80', delay: '0s' },
      { color: 'bg-lilac-200/50', pos: 'left-[-5%] bottom-[10%]', size: 'h-72 w-72', delay: '1s' },
      { color: 'bg-rose-200/40', pos: 'top-[30%] left-[40%]', size: 'h-64 w-64', delay: '2s' },
    ],
    accent: '#3a72f5',
  },
  6: {
    name: 'cream',
    base: 'bg-gradient-to-br from-cream-100 via-rose-100 to-peach-100',
    orbs: [
      { color: 'bg-cream-300/50', pos: 'left-[-10%] top-[10%]', size: 'h-80 w-80', delay: '0.5s' },
      { color: 'bg-rose-200/50', pos: 'right-[-10%] top-[40%]', size: 'h-72 w-72', delay: '1.5s' },
      { color: 'bg-peach-200/40', pos: 'bottom-[10%] left-[30%]', size: 'h-64 w-64', delay: '2.5s' },
    ],
    accent: '#e3a44f',
  },
  7: {
    name: 'rose-deep',
    base: 'bg-gradient-to-br from-rose-200 via-lilac-100 to-rose-100',
    orbs: [
      { color: 'bg-rose-300/60', pos: 'left-[-10%] top-[20%]', size: 'h-80 w-80', delay: '0s' },
      { color: 'bg-lilac-200/50', pos: 'right-[-10%] bottom-[15%]', size: 'h-72 w-72', delay: '1s' },
      { color: 'bg-rose-200/50', pos: 'top-[50%] left-[35%]', size: 'h-64 w-64', delay: '2s' },
    ],
    accent: '#d9264d',
  },
  8: {
    name: 'celebration',
    base: 'bg-gradient-to-br from-rose-100 via-lilac-100 to-peach-100',
    orbs: [
      { color: 'bg-rose-300/50', pos: 'left-[-10%] top-[10%]', size: 'h-80 w-80', delay: '0s' },
      { color: 'bg-lilac-200/50', pos: 'right-[-10%] top-[30%]', size: 'h-72 w-72', delay: '1s' },
      { color: 'bg-peach-200/50', pos: 'bottom-[10%] left-[20%]', size: 'h-64 w-64', delay: '2s' },
      { color: 'bg-mint-200/40', pos: 'bottom-[20%] right-[20%]', size: 'h-64 w-64', delay: '2.5s' },
    ],
    accent: '#f54267',
  },
};

export default function Background({ step }: { step: number }) {
  const theme = THEMES[step] ?? THEMES[1];

  const stars = useMemo(
    () =>
      Array.from({ length: 24 }, (_, i) => ({
        left: (i * 37) % 100,
        top: (i * 53) % 100,
        size: 2 + (i % 3),
        delay: (i * 0.15) % 3,
      })),
    []
  );

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      <div className={`absolute inset-0 ${theme.base} transition-all duration-1000`} />
      {theme.orbs.map((orb, i) => (
        <div
          key={`${theme.name}-${i}`}
          className={`absolute rounded-full blur-3xl ${orb.color} ${orb.pos} ${orb.size}`}
          style={{ animation: `float 8s ease-in-out ${orb.delay}s infinite` }}
        />
      ))}
      {stars.map((s, i) => (
        <div
          key={i}
          className="absolute rounded-full bg-white"
          style={{
            left: `${s.left}%`,
            top: `${s.top}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            animation: `twinkle ${2 + (i % 3)}s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}
