import { useEffect, useState, useMemo } from 'react';

type ConfettiPiece = {
  id: number;
  left: number;
  delay: number;
  duration: number;
  color: string;
  size: number;
  shape: 'square' | 'circle' | 'triangle' | 'star';
};

const COLORS = [
  '#f54267',
  '#e3a44f',
  '#4cbe88',
  '#3a72f5',
  '#ffa0b1',
  '#7fd6ab',
  '#8bb8ff',
  '#f3d9a8',
  '#c084fc',
  '#fb923c',
];

function makePieces(count: number): ConfettiPiece[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 2,
    duration: 2.5 + Math.random() * 3,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
    size: 8 + Math.random() * 10,
    shape: (['square', 'circle', 'triangle', 'star'] as const)[
      Math.floor(Math.random() * 4)
    ],
  }));
}

function Shape({ shape, size, color }: { shape: ConfettiPiece['shape']; size: number; color: string }) {
  if (shape === 'circle') {
    return <div style={{ width: size, height: size, background: color, borderRadius: '50%' }} />;
  }
  if (shape === 'triangle') {
    return (
      <div
        style={{
          width: 0,
          height: 0,
          borderLeft: `${size / 2}px solid transparent`,
          borderRight: `${size / 2}px solid transparent`,
          borderBottom: `${size}px solid ${color}`,
        }}
      />
    );
  }
  if (shape === 'star') {
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
        <path d="M12 2l2.4 7.4H22l-6 4.4 2.3 7.2-6.3-4.6-6.3 4.6L7.9 13.8 2 9.4h7.6z" />
      </svg>
    );
  }
  return <div style={{ width: size, height: size * 0.6, background: color, borderRadius: '2px' }} />;
}

export default function Confetti({
  count = 80,
  duration = 6000,
}: {
  count?: number;
  duration?: number;
}) {
  const [pieces, setPieces] = useState<ConfettiPiece[]>([]);
  const piecesMemo = useMemo(() => makePieces(count), [count]);

  useEffect(() => {
    setPieces(piecesMemo);
    const t = setTimeout(() => setPieces([]), duration);
    return () => clearTimeout(t);
  }, [piecesMemo, duration]);

  if (!pieces.length) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="absolute top-0"
          style={{
            left: `${p.left}%`,
            animation: `confetti-fall ${p.duration}s linear ${p.delay}s forwards`,
          }}
        >
          <Shape shape={p.shape} size={p.size} color={p.color} />
        </div>
      ))}
    </div>
  );
}
